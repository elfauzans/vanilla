<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body>

<!-- box 1 -->
<div class="vanilla_box1" id="box1_2">
<div class="container" style="height: 450px;">
	<div style="height: 200px;"></div>
	<div class="vanilla_peta1">
		<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d7903.1612574534!2d112.66018201852414!3d-7.9387909198512485!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2dd629a277983b27%3A0x9fcc62008366f34d!2sAraya+Bumi+Megah.+PT!5e0!3m2!1sen!2s!4v1412555239183" width="800" height="400" frameborder="0" style="border:0"></iframe>
	</div>
	<div class="vanilla_peta2"></div>
</div>
</div>
<!-- box 2 -->


<!-- box 3 -->
<div class="vanilla_box3">
<div class="container" align="center">
	<div style="height: 220px;"></div>
	
	We value Long Term Business Relationship, therefore Honesty and Quality will always be our Core Values.<br>
	We welcome you to Visit Our Office and Warehouse.
	
	<div style="clear: both; height: 80px;"></div>
</div>
</div>

<!-- box 1 -->

<!-- end of bigbox -->

<!-- box 1 -->

<!-- box 1 -->

<!-- box 1 -->

</body>
</html>
