<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body>

<!-- box 1 -->
<div class="vanilla_box1" id="box1_1">
<div class="container" style="height: 450px;">
	<div class="vanilla_box1_title">OUR PRODUCTS</div>
</div>
</div>
<!-- box 2 -->


<!-- box 3 -->
<div class="vanilla_box3">
<div class="container">
	<div style="height: 150px;"></div>
	
	<div class="vanilla_product">
		<div class="vanilla_product1"><a href="#bigbox_1"><img src="http://3.bp.blogspot.com/-0ABfrPXlSj0/VFg7j4huotI/AAAAAAAAG_k/qQFtSY8Qykw/s1600/product_vanilla.jpg"></a></div>
		<div class="vanilla_product2"></div>
		Vanilla
	</div>
	<!-- end of product-->
	<div class="vanilla_product">
		<div class="vanilla_product1"><a href="#bigbox_2"><img src="http://1.bp.blogspot.com/-zlPreRicNh8/VDdFtcxlQBI/AAAAAAAAGzc/yJYEKwz0UAY/s1600/product_blackpepper.jpg"></a></div>
		<div class="vanilla_product2"></div>
		Black Pepper
	</div>
	<!-- end of product-->
	
	<div class="vanilla_product">
		<div class="vanilla_product1"><a href="#bigbox_3"><img src="http://4.bp.blogspot.com/-2JnDGtMmDFw/VDdFyJVtQgI/AAAAAAAAGz0/p3QFybj_tRw/s1600/product_cinnamon.jpg"></a></div>
		<div class="vanilla_product2"></div>
		Cinnamon
	</div>
	<!-- end of product-->
	
	<div class="vanilla_product">
		<div class="vanilla_product1"><a href="#bigbox_4"><img src="http://2.bp.blogspot.com/-y9UW53WU4ws/VFg7iZcjE3I/AAAAAAAAG_U/uQr-Ixa6VYY/s1600/product_cardamom.jpg"></a></div>
		<div class="vanilla_product2"></div>
		Cardamom
	</div>
	<!-- end of product-->
	
	<div class="vanilla_product">
		<div class="vanilla_product1"><a href="#bigbox_5"><img src="http://4.bp.blogspot.com/-nmrZUuQlMWo/VFg7jcrQtGI/AAAAAAAAG_s/m-7vsZTpqzc/s1600/product_nutmeg.jpg"></a></div>
		<div class="vanilla_product2"></div>
		Nutmeg
	</div>
	<!-- end of product-->
	
	<div class="vanilla_product">
		<div class="vanilla_product1"><a href="#bigbox_6"><img src="http://1.bp.blogspot.com/-N6F-UvcLRbI/VDdFyZKw1SI/AAAAAAAAGz8/PFT43ylY9G4/s1600/product_coffee.jpg"></a></div>
		<div class="vanilla_product2"></div>
		Coffee
	</div>
	
	<!-- end of product-->
	<div class="vanilla_product">
		<div class="vanilla_product1"><a href="#bigbox_7"><img src="http://1.bp.blogspot.com/-3NU0Y3XnTaU/VFg7jmp-bnI/AAAAAAAAG_c/LcTBgz4-ZEA/s1600/product_patchouli.jpg"></a></div>
		<div class="vanilla_product2"></div>
		Patchouli Oil
	</div>
	<!-- end of product-->
	
	<div class="vanilla_product">
		<div class="vanilla_product1"><a href="#bigbox_8"><img src="http://2.bp.blogspot.com/-I68QA6PZJ_c/VDdFt0ji9mI/AAAAAAAAGzk/7cMbtYZmYvM/s1600/product_chili.jpg"></a></div>
		<div class="vanilla_product2"></div>
		Chili
	</div>
	<!-- end of product-->
	
	<div class="vanilla_product">
		<div class="vanilla_product1"><a href="#bigbox_9"><img src="http://1.bp.blogspot.com/-ECn21sN9e0Y/VFg7iu9MOoI/AAAAAAAAG_Q/BrbksxkKGo4/s1600/product_clove.jpg"></a></div>
		<div class="vanilla_product2"></div>
		Clove
	</div>

	<!-- end of product-->
	<div class="vanilla_product">
		<div class="vanilla_product1"><a href="#bigbox_9"><img src="assets/2.jpeg"></a></div>
		<div class="vanilla_product2"></div>
		Clove
	</div>
	<!-- end of product-->
	<div class="vanilla_product">
		<div class="vanilla_product1"><a href="#bigbox_9"><img src="assets/3.jpeg"></a></div>
		<div class="vanilla_product2"></div>
		Clove
	</div>
	<!-- end of product-->
	<div class="vanilla_product">
		<div class="vanilla_product1"><a href="#bigbox_9"><img src="assets/4.jpeg"></a></div>
		<div class="vanilla_product2"></div>
		Clove
	</div>
	<!-- end of product-->
	<div class="vanilla_product">
		<div class="vanilla_product1"><a href="#bigbox_9"><img src="assets/1.jpeg"></a></div>
		<div class="vanilla_product2"></div>
		Clove
	</div>
	<!-- end of product-->
	
	
	<div style="clear: both; height: 100px;"></div>
</div>
</div>

<!-- box 1 -->

<div class="vanilla_product_big_container" id="bigbox_1">

	<a href="#"><div class="vanilla_product_close">Close (X)</div></a>
					
	<div class="vanilla_product_big">				
		<div class="vanilla_product_big1"><img src="http://2.bp.blogspot.com/-4IPDbWi8hu4/VC4dMLhPC_I/AAAAAAAAGwg/tLZOdcLGurI/s1600/home_vanilla.jpg"></div>
		<ca4>VANILLA</ca4>					
		<div class="vanilla_product_big2">					
				<div class="table">
						<div class="tr">
							<div class="td1" style="width: 30%;">Colour</div>
							<div class="td" style="width: 70%;">Black Oily</div>
						</div>
						<div class="tr">
							<div class="td1">Brand Name</div>
							<div class="td">VANILLA PRIMACOMMODITY</div>
						</div>
						<div class="tr">
							<div class="td1">Processing</div>
							<div class="td">Cured</div>
						</div>
						<div class="tr">
							<div class="td1">Type</div>
							<div class="td">Tahitian, Planifolia</div>
						</div>
						<div class="tr">
							<div class="td1">Place of Origin</div>
							<div class="td">Papua New Guinea, Indonesia</div>
						</div>
						<div class="tr">
							<div class="td1">Model Number</div>
							<div class="td">101</div>
						</div>
						<div class="tr">
							<div class="td1">FOB Price</div>
							<div class="td">Contact Us</div>
						</div>
						<div class="tr">
							<div class="td1">Port</div>
							<div class="td">Indonesia</div>
						</div>
						<div class="tr">
							<div class="td1">Payment Terms</div>
							<div class="td">L/C, D/A, D/P, T/T, Western Union, MoneyGram, PAYPAL</div>
						</div>
						<div class="tr">
							<div class="td1">Min. Order Quantity</div>
							<div class="td">1 Kilogram</div>
						</div>
						<div class="tr">
							<div class="td1">Supply Ability</div>
							<div class="td">15000 Kilogram per Month</div>
						</div>
						<div class="tr">
							<div class="td1">Packaging</div>
							<div class="td">Inbox, inner plastic and paper, good vacuum plastic, or buyer request. Packing size:  1kg, 1 ons, 1 pound, as buyer request</div>
						</div>
						<div class="tr">
							<div class="td1">Delivery Time</div>
							<div class="td">3 days</div>
						</div>
					</div>
					<!--end of table-->									
		</div>				
	</div>				
</div>

<!-- end of bigbox -->

<div class="vanilla_product_big_container" id="bigbox_2">

	<a href="#"><div class="vanilla_product_close">Close (X)</div></a>
					
	<div class="vanilla_product_big">				
		<div class="vanilla_product_big1"><img src="http://1.bp.blogspot.com/-ACABp3yo-40/VC4dJi41x3I/AAAAAAAAGv0/Pz8pOTtLAHM/s1600/home_blackpepper.jpg"></div>
		<ca4>BLACK PEPPER</ca4>					
		<div class="vanilla_product_big2">					
				<div class="table">
						<div class="tr">
							<div class="td1" style="width: 30%;">Colour</div>
							<div class="td" style="width: 70%;"></div>
						</div>
						<div class="tr">
							<div class="td1">Brand Name</div>
							<div class="td"></div>
						</div>
						<div class="tr">
							<div class="td1">Processing</div>
							<div class="td"></div>
						</div>
						<div class="tr">
							<div class="td1">Type</div>
							<div class="td"></div>
						</div>
						<div class="tr">
							<div class="td1">Place of Origin</div>
							<div class="td"></div>
						</div>
						<div class="tr">
							<div class="td1">Model Number</div>
							<div class="td"></div>
						</div>
						<div class="tr">
							<div class="td1">FOB Price</div>
							<div class="td"></div>
						</div>
						<div class="tr">
							<div class="td1">Port</div>
							<div class="td"></div>
						</div>
						<div class="tr">
							<div class="td1">Payment Terms</div>
							<div class="td">L/C, D/A, D/P, T/T, Western Union, MoneyGram, PAYPAL</div>
						</div>
						<div class="tr">
							<div class="td1">Min. Order Quantity</div>
							<div class="td"></div>
						</div>
						<div class="tr">
							<div class="td1">Supply Ability</div>
							<div class="td"></div>
						</div>
						<div class="tr">
							<div class="td1">Packaging</div>
							<div class="td"></div>
						</div>
						<div class="tr">
							<div class="td1">Delivery Time</div>
							<div class="td"></div>
						</div>
					</div>
					<!--end of table-->									
		</div>				
	</div>				
</div>

<!-- end of bigbox -->

<div class="vanilla_product_big_container" id="bigbox_3">

	<a href="#"><div class="vanilla_product_close">Close (X)</div></a>
					
	<div class="vanilla_product_big">				
		<div class="vanilla_product_big1"><img src="http://2.bp.blogspot.com/-8rveW8zyirE/VC4dKrOBXUI/AAAAAAAAGwE/wSlFJ5PtWWc/s1600/home_cinnamon.jpg"></div>
		<ca4>CINNAMON</ca4>					
		<div class="vanilla_product_big2">					
				<div class="table">
						<div class="tr">
							<div class="td1" style="width: 30%;">Colour</div>
							<div class="td" style="width: 70%;">Yellow, Light Brown</div>
						</div>
						<div class="tr">
							<div class="td1">Brand Name</div>
							<div class="td">GOOD SPICES PRIMACOMMODITY</div>
						</div>
						<div class="tr">
							<div class="td1">Processing</div>
							<div class="td">Dried</div>
						</div>
						<div class="tr">
							<div class="td1">Type</div>
							<div class="td"></div>
						</div>
						<div class="tr">
							<div class="td1">Place of Origin</div>
							<div class="td">Indonesia</div>
						</div>
						<div class="tr">
							<div class="td1">Model Number</div>
							<div class="td">502</div>
						</div>
						<div class="tr">
							<div class="td1">FOB Price</div>
							<div class="td">Contact Us</div>
						</div>
						<div class="tr">
							<div class="td1">Port</div>
							<div class="td">Indonesia</div>
						</div>
						<div class="tr">
							<div class="td1">Payment Terms</div>
							<div class="td">L/C, D/A, D/P, T/T, Western Union, MoneyGram, PAYPAL</div>
						</div>
						<div class="tr">
							<div class="td1">Min. Order Quantity</div>
							<div class="td"></div>
						</div>
						<div class="tr">
							<div class="td1">Supply Ability</div>
							<div class="td">30 Ton per Month</div>
						</div>
						<div class="tr">
							<div class="td1">Packaging</div>
							<div class="td">Jute bag, gunny, box, plactic vacuum, as buyer request</div>
						</div>
						<div class="tr">
							<div class="td1">Delivery Time</div>
							<div class="td">3 Days</div>
						</div>
					</div>
					<!--end of table-->									
		</div>				
	</div>				
</div>

<!-- end of bigbox -->

<div class="vanilla_product_big_container" id="bigbox_4">

	<a href="#"><div class="vanilla_product_close">Close (X)</div></a>
					
	<div class="vanilla_product_big">				
		<div class="vanilla_product_big1"><img src="http://1.bp.blogspot.com/-j3_dOF2N8dY/VC4dJy7Kd9I/AAAAAAAAGv4/nqT3MNp-ag0/s1600/home_cardamom.jpg"></div>
		<ca4>CARDAMOM</ca4>					
		<div class="vanilla_product_big2">					
				<div class="table">
						<div class="tr">
							<div class="td1" style="width: 30%;">Colour</div>
							<div class="td" style="width: 70%;"></div>
						</div>
						<div class="tr">
							<div class="td1">Brand Name</div>
							<div class="td"></div>
						</div>
						<div class="tr">
							<div class="td1">Processing</div>
							<div class="td"></div>
						</div>
						<div class="tr">
							<div class="td1">Type</div>
							<div class="td"></div>
						</div>
						<div class="tr">
							<div class="td1">Place of Origin</div>
							<div class="td"></div>
						</div>
						<div class="tr">
							<div class="td1">Model Number</div>
							<div class="td"></div>
						</div>
						<div class="tr">
							<div class="td1">FOB Price</div>
							<div class="td"></div>
						</div>
						<div class="tr">
							<div class="td1">Port</div>
							<div class="td"></div>
						</div>
						<div class="tr">
							<div class="td1">Payment Terms</div>
							<div class="td">L/C, D/A, D/P, T/T, Western Union, MoneyGram, PAYPAL</div>
						</div>
						<div class="tr">
							<div class="td1">Min. Order Quantity</div>
							<div class="td"></div>
						</div>
						<div class="tr">
							<div class="td1">Supply Ability</div>
							<div class="td"></div>
						</div>
						<div class="tr">
							<div class="td1">Packaging</div>
							<div class="td"></div>
						</div>
						<div class="tr">
							<div class="td1">Delivery Time</div>
							<div class="td"></div>
						</div>
					</div>
					<!--end of table-->									
		</div>				
	</div>				
</div>

<!-- end of bigbox -->

<div class="vanilla_product_big_container" id="bigbox_5">

	<a href="#"><div class="vanilla_product_close">Close (X)</div></a>
					
	<div class="vanilla_product_big">				
		<div class="vanilla_product_big1"><img src="http://4.bp.blogspot.com/-54PbbJq1nvM/VC4dLdw3DuI/AAAAAAAAGwY/ZRxe6fC6owA/s1600/home_nutmeg.jpg"></div>
		<ca4>NUTMEG</ca4>					
		<div class="vanilla_product_big2">					
				<div class="table">
						<div class="tr">
							<div class="td1" style="width: 30%;">Colour</div>
							<div class="td" style="width: 70%;"></div>
						</div>
						<div class="tr">
							<div class="td1">Brand Name</div>
							<div class="td"></div>
						</div>
						<div class="tr">
							<div class="td1">Processing</div>
							<div class="td"></div>
						</div>
						<div class="tr">
							<div class="td1">Type</div>
							<div class="td"></div>
						</div>
						<div class="tr">
							<div class="td1">Place of Origin</div>
							<div class="td"></div>
						</div>
						<div class="tr">
							<div class="td1">Model Number</div>
							<div class="td"></div>
						</div>
						<div class="tr">
							<div class="td1">FOB Price</div>
							<div class="td"></div>
						</div>
						<div class="tr">
							<div class="td1">Port</div>
							<div class="td"></div>
						</div>
						<div class="tr">
							<div class="td1">Payment Terms</div>
							<div class="td">L/C, D/A, D/P, T/T, Western Union, MoneyGram, PAYPAL</div>
						</div>
						<div class="tr">
							<div class="td1">Min. Order Quantity</div>
							<div class="td"></div>
						</div>
						<div class="tr">
							<div class="td1">Supply Ability</div>
							<div class="td"></div>
						</div>
						<div class="tr">
							<div class="td1">Packaging</div>
							<div class="td"></div>
						</div>
						<div class="tr">
							<div class="td1">Delivery Time</div>
							<div class="td"></div>
						</div>
					</div>
					<!--end of table-->									
		</div>				
	</div>				
</div>

<!-- end of bigbox -->

<div class="vanilla_product_big_container" id="bigbox_6">

	<a href="#"><div class="vanilla_product_close">Close (X)</div></a>
					
	<div class="vanilla_product_big">				
		<div class="vanilla_product_big1"><img src="http://2.bp.blogspot.com/-N_GqL-W3OXo/VC4dK9cH_fI/AAAAAAAAGwQ/lUMCo92C_vw/s1600/home_coffee.jpg"></div>
		<ca4>COFFEE</ca4>					
		<div class="vanilla_product_big2">					
				<div class="table">
						<div class="tr">
							<div class="td1" style="width: 30%;">Colour</div>
							<div class="td" style="width: 70%;"></div>
						</div>
						<div class="tr">
							<div class="td1">Brand Name</div>
							<div class="td"></div>
						</div>
						<div class="tr">
							<div class="td1">Processing</div>
							<div class="td"></div>
						</div>
						<div class="tr">
							<div class="td1">Type</div>
							<div class="td"></div>
						</div>
						<div class="tr">
							<div class="td1">Place of Origin</div>
							<div class="td"></div>
						</div>
						<div class="tr">
							<div class="td1">Model Number</div>
							<div class="td"></div>
						</div>
						<div class="tr">
							<div class="td1">FOB Price</div>
							<div class="td"></div>
						</div>
						<div class="tr">
							<div class="td1">Port</div>
							<div class="td"></div>
						</div>
						<div class="tr">
							<div class="td1">Payment Terms</div>
							<div class="td">L/C, D/A, D/P, T/T, Western Union, MoneyGram, PAYPAL</div>
						</div>
						<div class="tr">
							<div class="td1">Min. Order Quantity</div>
							<div class="td"></div>
						</div>
						<div class="tr">
							<div class="td1">Supply Ability</div>
							<div class="td"></div>
						</div>
						<div class="tr">
							<div class="td1">Packaging</div>
							<div class="td"></div>
						</div>
						<div class="tr">
							<div class="td1">Delivery Time</div>
							<div class="td"></div>
						</div>
					</div>
					<!--end of table-->									
		</div>				
	</div>				
</div>

<!-- end of bigbox -->

<div class="vanilla_product_big_container" id="bigbox_7">

	<a href="#"><div class="vanilla_product_close">Close (X)</div></a>
					
	<div class="vanilla_product_big">				
		<div class="vanilla_product_big1"><img src="http://1.bp.blogspot.com/-J-ze9n76WUQ/VFg7iLAbj3I/AAAAAAAAG_M/AlczU-4ytxc/s1600/home_patchouli.jpg"></div>
		<ca4>PATCHOULI OIL</ca4>					
		<div class="vanilla_product_big2">					
				<div class="table">
						<div class="tr">
							<div class="td1" style="width: 30%;">Colour</div>
							<div class="td" style="width: 70%;"></div>
						</div>
						<div class="tr">
							<div class="td1">Brand Name</div>
							<div class="td"></div>
						</div>
						<div class="tr">
							<div class="td1">Processing</div>
							<div class="td"></div>
						</div>
						<div class="tr">
							<div class="td1">Type</div>
							<div class="td"></div>
						</div>
						<div class="tr">
							<div class="td1">Place of Origin</div>
							<div class="td"></div>
						</div>
						<div class="tr">
							<div class="td1">Model Number</div>
							<div class="td"></div>
						</div>
						<div class="tr">
							<div class="td1">FOB Price</div>
							<div class="td"></div>
						</div>
						<div class="tr">
							<div class="td1">Port</div>
							<div class="td"></div>
						</div>
						<div class="tr">
							<div class="td1">Payment Terms</div>
							<div class="td">L/C, D/A, D/P, T/T, Western Union, MoneyGram, PAYPAL</div>
						</div>
						<div class="tr">
							<div class="td1">Min. Order Quantity</div>
							<div class="td"></div>
						</div>
						<div class="tr">
							<div class="td1">Supply Ability</div>
							<div class="td"></div>
						</div>
						<div class="tr">
							<div class="td1">Packaging</div>
							<div class="td"></div>
						</div>
						<div class="tr">
							<div class="td1">Delivery Time</div>
							<div class="td"></div>
						</div>
					</div>
					<!--end of table-->									
		</div>				
	</div>				
</div>

<!-- end of bigbox -->

<div class="vanilla_product_big_container" id="bigbox_8">

	<a href="#"><div class="vanilla_product_close">Close (X)</div></a>
					
	<div class="vanilla_product_big">				
		<div class="vanilla_product_big1"><img src="http://4.bp.blogspot.com/-Ryv2Pizsmew/VC4dKK0FBmI/AAAAAAAAGwA/PX4LLGQ2ZXA/s1600/home_chili.jpg"></div>
		<ca4>CHILI</ca4>					
		<div class="vanilla_product_big2">					
				<div class="table">
						<div class="tr">
							<div class="td1" style="width: 30%;">Colour</div>
							<div class="td" style="width: 70%;">Red</div>
						</div>
						<div class="tr">
							<div class="td1">Brand Name</div>
							<div class="td">CHILI PRIMACOMMODITY</div>
						</div>
						<div class="tr">
							<div class="td1">Processing</div>
							<div class="td">Dried</div>
						</div>
						<div class="tr">
							<div class="td1">Type</div>
							<div class="td">Whole</div>
						</div>
						<div class="tr">
							<div class="td1">Place of Origin</div>
							<div class="td">Indonesia</div>
						</div>
						<div class="tr">
							<div class="td1">Model Number</div>
							<div class="td">401</div>
						</div>
						<div class="tr">
							<div class="td1">FOB Price</div>
							<div class="td">Contact Us</div>
						</div>
						<div class="tr">
							<div class="td1">Port</div>
							<div class="td">Indonesia</div>
						</div>
						<div class="tr">
							<div class="td1">Payment Terms</div>
							<div class="td">L/C, D/A, D/P, T/T, Western Union, MoneyGram, PAYPAL</div>
						</div>
						<div class="tr">
							<div class="td1">Min. Order Quantity</div>
							<div class="td">1 MTON</div>
						</div>
						<div class="tr">
							<div class="td1">Supply Ability</div>
							<div class="td">50 Ton per Day</div>
						</div>
						<div class="tr">
							<div class="td1">Packaging</div>
							<div class="td">Jute bag, gunny, box, plactic vacuum, as buyer request</div>
						</div>
						<div class="tr">
							<div class="td1">Delivery Time</div>
							<div class="td">3 days</div>
						</div>
					</div>
					<!--end of table-->									
		</div>				
	</div>				
</div>

<!-- end of bigbox -->


<div class="vanilla_product_big_container" id="bigbox_9">

	<a href="#"><div class="vanilla_product_close">Close (X)</div></a>
					
	<div class="vanilla_product_big">				
		<div class="vanilla_product_big1"><img src="http://3.bp.blogspot.com/--8JNaZ5npwg/VDdFpSwfEYI/AAAAAAAAGzU/B1Qztxxryy0/s1600/home_clove.jpg"></div>
		<ca4>CLOVE</ca4>					
		<div class="vanilla_product_big2">					
				<div class="table">
						<div class="tr">
							<div class="td1" style="width: 30%;">Colour</div>
							<div class="td" style="width: 70%;"></div>
						</div>
						<div class="tr">
							<div class="td1">Brand Name</div>
							<div class="td"></div>
						</div>
						<div class="tr">
							<div class="td1">Processing</div>
							<div class="td"></div>
						</div>
						<div class="tr">
							<div class="td1">Type</div>
							<div class="td"></div>
						</div>
						<div class="tr">
							<div class="td1">Place of Origin</div>
							<div class="td"></div>
						</div>
						<div class="tr">
							<div class="td1">Model Number</div>
							<div class="td"></div>
						</div>
						<div class="tr">
							<div class="td1">FOB Price</div>
							<div class="td"></div>
						</div>
						<div class="tr">
							<div class="td1">Port</div>
							<div class="td"></div>
						</div>
						<div class="tr">
							<div class="td1">Payment Terms</div>
							<div class="td">L/C, D/A, D/P, T/T, Western Union, MoneyGram, PAYPAL</div>
						</div>
						<div class="tr">
							<div class="td1">Min. Order Quantity</div>
							<div class="td"></div>
						</div>
						<div class="tr">
							<div class="td1">Supply Ability</div>
							<div class="td"></div>
						</div>
						<div class="tr">
							<div class="td1">Packaging</div>
							<div class="td"></div>
						</div>
						<div class="tr">
							<div class="td1">Delivery Time</div>
							<div class="td"></div>
						</div>
					</div>
					<!--end of table-->									
		</div>				
	</div>				
</div>

<!-- end of bigbox -->

<!-- box 1 -->

<!-- box 1 -->

<!-- box 1 -->

</body>
</html>
