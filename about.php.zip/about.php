<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body>

<!-- box 1 -->
<!-- box 2 -->

<div class="vanilla_box2" style="box-shadow: inset 0px 0px 30px -2px #086363;">
	<div class="container">
		<div style="height: 150px;"></div>
		
		<ca1>COMPANY <cc2>PROFILE<cc2></ca1>
		<br><br>
		<div style="width: 90%;">
		Primacommodity has many experiences for many years plantations, curing and fermentations vanilla beans.( More than 25 years ) Now primacommodity produce high quality vanilla beans,very strong aromatic, plum,black oily.no split,no mould vanilla beans. We have luxury,gourmet vanilla beans, extract grade vanilla beans, premium vanilla ground powder 100% pure, and vanilla extract liquid double fold.	We also supply CARDAMON, CLOVE,NUTMEG,MACE,LONG PEPPER,CINNAMON,BLACK PEPPER and SPICES ORIGIN INDONESIA
		</div>

		<div style="height: 150px;"></div>
	</div>
</div>
<!-- box 3 -->

<div class="vanilla_box3">
<div class="container">
	<div style="height: 50px;"></div>
	
	<div class="vanilla_box3c">
		<div style="height: 20px;"></div>
		<ca4>BASIC COMPANY INFORMATION</ca4>
	</div>
	
	<div class="table" style="width: 100%;">
		<div class="tr">
			<div class="td1" style="width: 25%;">Company Name</div>
			<div class="td" style="width: 75%;">PRIMACOMMODITY LIMITED</div>
		</div>
		<div class="tr">
			<div class="td1">Business Type</div>
			<div class="td">Plantations, Manufacturer,Bulk Wholesaler,</div>
		</div>
		<div class="tr">
			<div class="td1">Product/Service (We Sell)</div>
			<div class="td">
				<ca6>SPICES</ca6><br>
				Gourmet Indonesia vanilla beans planifolia , Tahitian PNG, vanilla ground powder 100% pure. Super quality nutmeg abc, ss,clove, cardamom, long pepper, cubeb, ginger, coffee arabica & robusta,  betelnut, cinnamon stick/powder/cut,  pepper, pin head pepper, chilli, turmeric, cocoa,clove stem,
				<br><br>
				
				<ca6>ESSENTIAL OILS</ca6><br>
				Patchouly Oil, Nutmeg Oil, Black /White  Pepper Oil, Clove Stem Oil .
				<br><br>
				
				<ca6>TROPICAL FRUITS</ca6><br>
				Manggosteen, Manggo, Melon, Apple, Rambutan ,Durian, Jack Fruit, Star Fruit, Pineapple, Dragon Fruit, etc.
				<br><br>
				
				<ca6>FOREST WOODS</ca6><br>
				Sappan Wood, Sandal Wood, Agar Wood, Acacia Cathecu.
				<br><br>
				
			
			</div>
		</div>
		<div class="tr">
			<div class="td1">Product/Service(We Buy)</div>
			<div class="td">Vanilla Beans</div>
		</div>
		<div class="tr">
			<div class="td1">Brands</div>
			<div class="td">PRIMACOMMODITY</div>
		</div>
		<div class="tr">
			<div class="td1">Number of Employees</div>
			<div class="td">51 - 100 People</div>
		</div>
		<div class="tr">
			<div class="td1">Main Markets</div>
			<div class="td">North America, South America, Southeast Asia, Africa, Oceania, Mid East, Eastern Asia, China, USA, Canada, Europe</div>
		</div>
		<div class="tr">
			<div class="td1">Main Customers</div>
			<div class="td">USA, Europe,Australia, China, Japan, Korea, Singapore, Malaysia,Asia, Middle East</div>
		</div>
		<div class="tr">
			<div class="td1">Total Annual Sales Volume</div>
			<div class="td">US$5 Million - US$10 Million</div>
		</div>
		<div class="tr">
			<div class="td1">Export Percentage</div>
			<div class="td">91% - 100%</div>
		</div>
		<div class="tr">
			<div class="td1">Total Annual Purchase Volume</div>
			<div class="td">US$5 Million - US$10 Million</div>
		</div>		
		
	</div>
	<!--batas table-->

	
	
	<div style="height: 100px;"></div>
</div>
</div>
<!-- box 1 -->


<!-- box 1 -->


<!-- box 1 -->

<!-- box 1 -->

<!-- box 1 -->

</body>
</html>
