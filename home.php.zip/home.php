<html>

<head>
	<title>Untitled Document</title>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body>

	<!-- box 1 -->
	<div class="vanilla_box1">
		<div class="vanilla_box1_container">
			<div class="slider6_a1"></div>
			<div class="slider6_a2"></div>
			<div class="slider6_a3"></div>

			<div class="vanilla_box1_borderleft"><img src="http://4.bp.blogspot.com/-Z5SFNbuqRkU/VEXemHJ0zzI/AAAAAAAAG08/hHj8g6_1-g4/s1600/border_box2.png" height="450"></div>
			<div class="vanilla_box1_borderright"><img src="http://4.bp.blogspot.com/-Z5SFNbuqRkU/VEXemHJ0zzI/AAAAAAAAG08/hHj8g6_1-g4/s1600/border_box2.png" height="450"></div>
		</div>
	</div>
	<!-- box 2 -->

	<!-- Banner -->


	<!-- Section di bawah banner -->
	<div class="main-content">

		<div class="welcome-message">
			<h2>Our Life begins with the story of Vanilla</h2>
			<p>
				In the region where we grew up in Malang, east java indonesia, vanilla plantation had been majorly developing since long time ago,
				we are noticed how vanilla had been helping a lot of local farmers to support their life especially women in that area.
				<br>
				our experienced more than 25 years of developing vanilla in indonesian.
				<br>
				we started to dream about how to introduce the incredible vanilla from indonesia to the world.
				<br>

				Now finally we connected the world throught vanilla and introduce different kind of exotic vanilla from indonesia.
				<br>
				We want to say to the world that :
				<br>
				<b><em>“Success is not just about the story of winning and gaining but is all about the process of how we make it happen".</em></b>

			</p>


		</div>
	</div>

	<div class="vanilla_box2" style="box-shadow: inset 0px 0px 30px -2px #003000;">
		<img src="assets/daun.png" class="leaf left" alt="Daun" />
		<img src="assets/daun.png" class="leaf right" alt="Daun" />


		<div class="container">
			<div style="height: 50px;"></div>

			<div class="vanilla_box2a">
				<div align="center">
					<h2>PRIMACOMMODITY LIMITED HAS BEEN ESTABLISHED </h2>
				</div>
				<div class="vanilla_box2_border1"></div>
				<div class="kotak2" style="width: 50%; padding-right: 5%; border-right: 3px;">
					<cb>WE ARE BULK WHOLESALE SUPPLIER / EXPORTIR INDONESIA VANILLA BEANS AND TAHITIAN PNG.
						We can supply many tons quantity in container by sea freight or by airfreight ( DHL, FEDEX, TNT ,EMS POST ) as clients request.
						Our specialty is in Vanilla Beans,with long years of experiences.( fMore than 25 years ).We have vanilla plantations in Java Island,Sulawesi Island,Lombok Island ( Indonesia )
						We supply Indonesia vanilla beans Planifolia and Tahitian PNG,LUXURY GRADE,GOURMET GRADE,EXTRACT GRADE,ALLGRADE QUALITY AND PREMIUM VANILLA GROUND POWDER 100% PURE,VANILLA EXTRACT LIQUID DOUBLE FOLD, We can suplly to you continuous all years round.
						We also supply CARDAMON, CLOVE,NUTMEG,MACE,LONG PEPPER,CINNAMON,BLACK PEPPER and SPICES ORIGIN INDONESIA</cb><br>

				</div>
				<div class="kotak2" style="width: 40%; left: 5%;">
					<ca2>OUR CORE VALUES</ca2>
					<ca3>
						<ul>
							<li>HONESTY</li>
							<li>TRUST</li>
							<li>HIGH QUALITY 100% GUARANTEE</li>
							<li>COMMITMENT-RESPONSIBILITY</li>
							<li>GOOD LONG-TERM BUSINESS RELATIONSHIP</li>
						</ul>
					</ca3>
				</div>
				<div style="clear: both;"></div>
			</div>

			<div style="height: 200px;"></div>
		</div>
	</div>
	<!-- box 3 -->
	<div class="vanilla_box3">
		<div class="container">
			<div style="height: 350px;"></div>
			<div class="vanilla_box3a">
				<div class="kotak1" style="top: 10px; left: 10px;"><img src="http://2.bp.blogspot.com/-4IPDbWi8hu4/VC4dMLhPC_I/AAAAAAAAGwg/tLZOdcLGurI/s1600/home_vanilla.jpg"></div>
				<div class="kotak1" style="top: 50px; left: 470px; width: 350px;">
					<ca4>OUR VANILLA BEAN QUALITY STANDARD</ca4>
					<br><br>
					<div class="vanilla_bullet1">BLACK OILY </div>
					<div class="vanilla_bullet1">MOISTURE 28-33% </div>
					<div class="vanilla_bullet1">VANILLIN CONTENT 2% UP</div>
					<div class="vanilla_bullet1">LENGHT 14 CM - 21 CM UP</div>
					<ca5>STRONG AROMATIC, MOIST, PLUM, OLD RIPE HARVEST, NO MOULD, NO SPLIT.</ca5>
				</div>
			</div>

			<div class="vanilla_box3b">We also supply other spices</div>

			<div class="vanilla_homeproduct">
				<div class="vanilla_homeproduct_pic"><img src="http://1.bp.blogspot.com/-ACABp3yo-40/VC4dJi41x3I/AAAAAAAAGv0/Pz8pOTtLAHM/s1600/home_blackpepper.jpg" style="top: -0px;"></div>

			</div>
			<!--batas homeproduct-->

			<div class="vanilla_homeproduct">
				<div class="vanilla_homeproduct_pic"><img src="http://2.bp.blogspot.com/-8rveW8zyirE/VC4dKrOBXUI/AAAAAAAAGwE/wSlFJ5PtWWc/s1600/home_cinnamon.jpg" style="top: -0px;"></div>

			</div>
			<!--batas homeproduct-->

			<div class="vanilla_homeproduct">
				<div class="vanilla_homeproduct_pic"><img src="http://1.bp.blogspot.com/-j3_dOF2N8dY/VC4dJy7Kd9I/AAAAAAAAGv4/nqT3MNp-ag0/s1600/home_cardamom.jpg" style="top: -0px;"></div>

			</div>
			<!--batas homeproduct-->

			<div class="vanilla_homeproduct">
				<div class="vanilla_homeproduct_pic"><img src="http://4.bp.blogspot.com/-54PbbJq1nvM/VC4dLdw3DuI/AAAAAAAAGwY/ZRxe6fC6owA/s1600/home_nutmeg.jpg" style="top: -0px;"></div>

			</div>
			<!--batas homeproduct-->

			<div class="vanilla_homeproduct">
				<div class="vanilla_homeproduct_pic"><img src="http://2.bp.blogspot.com/-N_GqL-W3OXo/VC4dK9cH_fI/AAAAAAAAGwQ/lUMCo92C_vw/s1600/home_coffee.jpg" style="top: -0px;"></div>

			</div>
			<!--batas homeproduct-->

			<div class="vanilla_homeproduct">
				<div class="vanilla_homeproduct_pic"><img src="http://1.bp.blogspot.com/-J-ze9n76WUQ/VFg7iLAbj3I/AAAAAAAAG_M/AlczU-4ytxc/s1600/home_patchouli.jpg" style="top: -0px;"></div>

			</div>
			<!--batas homeproduct-->

			<div class="vanilla_homeproduct">
				<div class="vanilla_homeproduct_pic"><img src="http://4.bp.blogspot.com/-Ryv2Pizsmew/VC4dKK0FBmI/AAAAAAAAGwA/PX4LLGQ2ZXA/s1600/home_chili.jpg" style="top: -0px;"></div>

			</div>
			<!--batas homeproduct-->

			<div class="vanilla_homeproduct">
				<div class="vanilla_homeproduct_pic"><img src="http://3.bp.blogspot.com/--8JNaZ5npwg/VDdFpSwfEYI/AAAAAAAAGzU/B1Qztxxryy0/s1600/home_clove.jpg" style="top: -0px;"></div>

			</div>
			<!--batas homeproduct-->



			<div style="clear: both; height: 100px;"></div>
		</div>
	</div>

	<!-- box 1 -->


	<!-- box 1 -->


	<!-- box 1 -->

	<!-- box 1 -->

	<!-- box 1 -->



	<div class="vanilla_box2" style="box-shadow: inset 0px 0px 30px -2px #003000;">
		<h2 style="text-align: center; 
           color: black; 
           font-size: 35px;  
           font-family: century gothic; 
           text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.3);">
			<em>We are available for any further inquiries you may have</em>
		</h2>

		<hr>
		<img src="assets/daun.png" class="leaf bottom-left" alt="Daun" />
		<img src="assets/daun.png" class="leaf right" alt="Daun" />

		<div class="slide-container">

			<div class="slide-content">
				<div class="card-wrapper">
					<div class="card">
						<div class="image-content">
							<span class="overlay"></span>
							<div class="card-image">
								<img src="assets/susilo.jpeg" alt="Mr. susilo" class="card-img">
							</div>
						</div>

						<div class="card-content">
							<h2 class="name">Mr. Susilo</h2>
							<div class="contact">
								<p><strong>WhatsApp:</strong>
									<a href="https://wa.me/6281519997317" target="_blank">+62 815-1999-7317</a>
								</p>
								<p><strong>Email:</strong>
									<a href="mailto:tiga.aksara123@gmail.com" target="_blank">tiga.aksara123@gmail.com</a>
								</p>
							</div>
						</div>
					</div>
					<div class="card">
						<div class="image-content">
							<span class="overlay"></span>
							<div class="card-image">
								<img src="assets/hermanto.jpeg" alt="Mr. Hermanto" class="card-img">
							</div>
						</div>

						<div class="card-content">
							<h2 class="name">Mr. Hermanto</h2>
							<div class="contact">
								<p><strong>WhatsApp:</strong>
									<a href="https://wa.me/6281357514358" target="_blank">+62 813-5751-4358</a>
								</p>
								<p><strong>Email:</strong>
									<a href="mailto:primacommodity@yahoo.com" target="_blank">primacommodity@yahoo.com</a>

								</p>
							</div>
						</div>
					</div>
					<div class="card">
						<div class="image-content">
							<span class="overlay"></span>
							<div class="card-image">
								<img src="assets/woman.png" alt="Mr. Hermanto" class="card-img">
							</div>
						</div>

						<div class="card-content">
							<h2 class="name">Mrs. Lia</h2>
							<div class="contact">
								<p><strong>WhatsApp:</strong>
									<a href="https://wa.me/628122820995" target="_blank">+62 812-2820-995</a>
								</p>
								<p><strong>Email:</strong>
									<a href="mailto:apriliasetyadi@gmail.com" target="_blank">apriliasetyadi@gmail.com</a>
								</p>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<br>
	<br>
	<br>
	<br>


</body>

</html>